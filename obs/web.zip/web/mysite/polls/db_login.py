import pymysql
db = pymysql.connect(host='124.70.156.124', port=3306, user='root', passwd='Isoftstone@1234',db='our_db', charset='utf8') #, charset='utf8'
cursor = db.cursor()
cursor.execute("select version()")

data = cursor.fetchone()
print(" Database Version:%s" % data)
#---------------------------------------


def Authenticate(user_id,password):
    sql = 'select * from user_pwd'
    cursor.execute(sql)
    data = cursor.fetchall()
    for i in data:
        if (user_id, password) == (i[0], i[2]):
            return True


def insert_temp_list(a,b):
    s1 = "insert into temp values("
    s2 = "'" + a + "'" + ',' + "'" + b + "'"
    s3 = ');'
    s0 = s1 + s2 + s3
    print(s0)
    cursor.execute(s0)
    db.commit()

def clean_temp_list():
    sql = "delete from temp"
    cursor.execute(sql)
    db.commit()

def clean_user_log():
    sql = "delete from user_log"
    cursor.execute(sql)
    db.commit()

def insert_object_list(a,b,c,d):
    sql = "insert into list values(" +  a +  ',' + "'" + b + "'" + ',' + "'" + c + "'" + ',' + "'" + d + "'" + ")"
    #print(sql)
    cursor.execute(sql)
    db.commit()
