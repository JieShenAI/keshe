AK = 'GCCIWDYQJUWRYOSHLP0J'
SK = 'EUIXDZqlSS6ZkCppX9rqMG4ziMAkRjSmibEX0z4H'
server = 'https://obs.cn-north-4.myhuaweicloud.com'
bucketName = 'obs-09-demo'

from .db_login import *
from obs import *
import os
from obs import DeleteObjectsRequest, Object
# -------------------------------------------------初始化obs客户端------------------------------------------
obsClient = ObsClient(access_key_id=AK, secret_access_key=SK, server=server)
bucketClient = obsClient.bucketClient(bucketName)


#----------------------------------------------------创建文件夹-------------------------------------------
#filepath为创建文件夹的所属的路径，若路径不存在则会创建一个同名的文件夹
def CreateFile(filepath):
    resp = obsClient.putContent(bucketName, filepath, content=None)
    if resp.status < 300:
        reply = "yes"
        return reply
    else:
        print('errorCode:', resp.errorCode)
        print('errorMessage:', resp.errorMessage)
        reply = "no"
        return reply
#示例
def CreateFile_demo():
    filepath='movie/冒险/'
    CreateFile(filepath)

#----------------------------------------------------文件对象上传------------------------------------------
#objectname为上传文件的命名，filepath为上传文件在本地的路径
def CreateObjects(objectname,filepath):
    resp = obsClient.putFile(bucketName, objectname, file_path=filepath)
    if resp.status < 300:
        print('Create object ' + objectname + ' successfully!\n')
    else:
        print('上传失败！')
#示例
def CreateObjects_demo():
    #本地路径
    filepath1 = r'D:\music\夜曲.mp3'

    #文件名有两种方式一种，自己输入，另一种就是直接用上传文件的名字
    #case:0
    objectname1=input("输入文件名：")
    objectname1= objectname1 + os.path.splitext(os.path.split(filepath1)[1])[1]
    print(objectname1)
    CreateObjects(objectname1, filepath1)

    #case:1
    objectname2 = os.path.split(filepath1)[1]
    print(objectname2)
    CreateObjects(objectname2, filepath1)



#-------------------------------------------------文件对象下载-----------------------------------------------
def Downloadobjects(objectname,downloadpath):
    downloadpath = downloadpath + '\\' + os.path.basename(objectname)
    legal_downloadpath = ""
    for i in range(len(downloadpath)):
        if downloadpath[i] == '\\':
            legal_downloadpath += '/'
        else:
            legal_downloadpath += downloadpath[i]
    print(legal_downloadpath)
    resp = obsClient.getObject(bucketName, objectname, downloadPath=legal_downloadpath)
    if resp.status < 300:
        print('下载成功！')
        print('url:', resp.body.url)
    else:
        print('errorCode:', resp.errorCode)
        print('errorMessage:', resp.errorMessage)
        print('下载失败！')

#----------------------------------------------------复制+移动---------------------------------------------------
#sourcebucketname(源桶名) ，sourceobjectname（源文件名），destbucketname（目的桶名），destobjectname（目的文件名）
def CopyObject(sourceobjectname,destobjectname):
    destobjectname = destobjectname + os.path.basename(sourceobjectname)
    resp = obsClient.copyObject(bucketName, sourceobjectname, bucketName, destobjectname)
    if resp.status < 300:
        print("复制成功！")
    else:
        print('errorCode:', resp.errorCode)
        print('errorMessage:', resp.errorMessage)
        print("复制失败！")

#----------------------------------------------------删除------------------------------------------------
#删除单个对象
def DeleteObject_single(objectname):
    resp = obsClient.deleteObject(bucketName, objectname)
    if resp.status < 300:
        print("成功删除!")
    else:
        print('errorCode:', resp.errorCode)
        print('errorMessage:', resp.errorMessage)
        print("删除失败！")
#单个文件删除示例
def DeleteObject_demo_01():
    bucketname = bucketName
    objectname = 'myobjects'
    #objectname = 'music/古风/夜曲.mp3' 为删除文件夜曲.mp3
    #objectname = 'music/古风/' 当古风目录下的文件为空的时候，删除目录古风
    DeleteObject_single(bucketname, objectname)#示例

#批量删除对象
def DeleteObject_batch(bucketname):
    deleteObjectsRequest = DeleteObjectsRequest()
    # 设置为verbose模式
    deleteObjectsRequest.quiet = False
    k = '1'
    deleteObjectsRequest.objects =[]
    while k != '0':
        key=input("输入删除的文件名字：")
        deleteObjectsRequest.objects.append(Object(key=key, versionId=None))
        k = input("添加删除文件完毕输入0,否则输入任意键后继续添加:")

    resp = obsClient.deleteObjects(bucketname, deleteObjectsRequest=deleteObjectsRequest)
    if resp.status < 300:
        print('requestId:', resp.requestId)
        # 获取删除成功的对象
        if resp.body.deleted:
            index = 1
            for delete in resp.body.deleted:
                print('deleted[', index, ']:')
                print('name:', delete.key)
                #print('versionId:', delete.versionId)
                print("删除成功！")
                index += 1
        # 获取删除失败的对象
        if resp.body.error:
            index = 1
            for err in resp.body.error:
                print('error[', index, ']:')
                print('name:', err.key)
                print('code:', err.code)
                print('message:', err.message)
                print('删除失败！')
    else:
        print('errorCode:', resp.errorCode)
        print('errorMessage:', resp.errorMessage)

#批量删除示例
def DeleteObject_demo_02():
    bucketname = bucketName
    DeleteObject_batch(bucketname)


#---------------------------------------------------列举对象----------------------------------------------
def ListObjects():
    resp = obsClient.listObjects(bucketName)
    if resp.status < 300:
        print("yes")
        #print('requestId:', resp.requestId)
        sql = 'delete from list'
        cursor.execute(sql)
        db.commit()
        index = 1
        for content in resp.body.contents:
            a = str (index)
            b = content.key
            c = 'create_user'
            d = 'create_time'
            insert_object_list(a,b,c,d)
            index += 1
    else:
        print('errorCode:', resp.errorCode)
        print('errorMessage:', resp.errorMessage)
        print("获取失败！")


#----------------------------------------查看属性----------------------
def getObjectMetadata(objectname):
    objectname = os.path.basename(objectname)
    resp = obsClient.getObjectMetadata(bucketName, objectname)
    if resp.status < 300:
        contentType = resp.body.contentType
        contentLength = resp.body.contentLength
        contentLength = str (contentLength)
    #清空缓存
        sql = "delete from attribute"
        cursor.execute(sql)
        db.commit()
    #插入当前属性
        sql = "insert into attribute values( " + "'" + contentType + "'" + "," + "'" + contentLength + "'" + ");"
        print(sql)
        cursor.execute(sql)
        db.commit()
        reply = 'yes'
        return reply
    else:
        reply = 'no'
        return reply
#--------------------------------------------分享------------------------------------

#expires参数的意思是链接的有效期，单位为秒
def Create_Share(objectname,day):
    expires = day * 24 * 60 * 60  # 将天转化为秒
    res = obsClient.createSignedUrl('GET', bucketName, objectname, expires= expires)
    url = res.signedUrl
    return url
