AK = 'GCCIWDYQJUWRYOSHLP0J'
SK = 'EUIXDZqlSS6ZkCppX9rqMG4ziMAkRjSmibEX0z4H'
server = 'https://obs.cn-north-4.myhuaweicloud.com'
bucketName = 'obs-09-demo'

from obs import *
# -------------------------------------------------初始化obs客户端------------------------------------------
obsClient = ObsClient(access_key_id=AK, secret_access_key=SK, server=server)
bucketClient = obsClient.bucketClient(bucketName)

def getObjectMetadata(objectname):
    resp = obsClient.getObjectMetadata(bucketName, objectname)
    if resp.status < 300:
        contentType = resp.body.contentType
        print(contentType)
        contentLength = resp.body.contentLength
        print(contentLength)
        contentLength = str (contentLength)
getObjectMetadata("music01/夜曲.mp3")