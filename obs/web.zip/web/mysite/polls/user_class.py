import string
import random
import pymysql
import yagmail
db = pymysql.connect(host='124.70.156.124', port=3306, user='root', passwd='Isoftstone@1234',db='our_db',charset='utf8',)
cursor = db.cursor()



def insert_data_list(a,b,c):
    s1 = "insert into data values("
    s2 = "'" + a + "'" + ',' + "'" + b + "'" + ',' + "'" + c + "'"
    s3 = ');'
    s0 = s1 + s2 + s3
    cursor.execute(s0)
    db.commit()

def clean_data_list():
    sql = "delete from data"
    cursor.execute(sql)
    db.commit()

def send_verify_code(send_mail, recv_mail):
    yag = yagmail.SMTP(send_mail, password='WBVOMSMXEBWSTFBI', host='smtp.163.com')
    value = ''.join(random.sample(string.digits + string.ascii_uppercase + string.ascii_lowercase, 8))
    contents = ['如果这不是你本人操作请忽略。', '如果是本人操作，请提交如下的验证码:', value]
    # 参数 收件人，主题，正文内容
    yag.send(recv_mail, '修改密码', contents)
    return value


class user:
    '''
    私有方法，为了拒绝从外部调用。
    如果管理员调用修改函数，得到了返回值为False的原因：
        值得注意的是：我们修改（更新）的值不能和原来的值一样，修改就一定要改，如果修改后的值和原来的值一样，会return False;
        比如：         用户密码是: '123456'
            提交修改后的新密码为: '123456'
            新密码和原来密码一样，会 return False
    '''

    # 当用户忘记密码的时候,pwd此项为空,可以不填
    def __init__(self, email, pwd=''):

        self.__connect_db()
        self.email = email;
        self.__pwd = pwd;  # 密码属于敏感属性，设置为私有
        self.live = self.__login()  # self.live为True,用户登录成功，为False登录失败
        # 一旦用户登录成功，前端同学可以直接调用用户的下列属性，已经全部实例化完毕
        # self.name
        # self.phone
        # self.is_admin
        # self.state
        # self.company

    def __delete__(self):
        # 类销毁的时候与mysql断开连接
        self.db.close()

    def __connect_db(self):
        self.db = pymysql.connect(host='124.70.156.124', port=3306, user='root', passwd='Isoftstone@1234', db='our_db')
        self.cursor = self.db.cursor()

    def fill(self, s):
        return '\'' + s + '\''

    def add_log_fail(self, s):
        '''
        用户登录失败记录
        '''
        sql = 'insert into user_log(name,action,oper_time) values(' + self.fill(self.email) + ',' + self.fill(
            s) + ',now());'
        # 't','查询用户信息',now());'
        # print(sql)

        try:
            self.cursor.execute(sql)
            self.db.commit()
            return True
        except Exception as e:
            print(e)
            self.db.rollback()
            return False

    def add_log_action(self, s):
        '''
        用户登录成功后，操作记录
        '''
        # 即使用户没有登录，也会进行日志记录。

        sql = 'insert into user_log(name,action,oper_time) values(' + self.fill(self.name) + ',' + self.fill(
            s) + ',now());'
        # 't','查询用户信息',now());'
        # print(sql)

        try:
            self.cursor.execute(sql)
            self.db.commit()
            return True
        except Exception as e:
            print(e)
            self.db.rollback()
            return False

    def show_log(self, n=10):
        '''
        n,返回多少条日志记录
        '''
        if self.live == False:
            return False
        if self.is_admin == 0:
            return False

        sql = 'select * from user_log order by id desc limit ' + str(n) + ';'
        try:
            n = self.cursor.execute(sql)
            data = self.cursor.fetchall()
            return data
        except Exception as e:
            print(e)
            return False

    def __login(self):
        '''
        用户登录模块
        前端提供给我们user和pwd,
        用户登录进行身份验证，查表自动实例化用户的各项属性
        :return: True 登录成功 ， False 登录失败
        '''
        # 错误示例: 'select pwd_md5 from user_pwd where name = ' +str(user);
        # 因为是'张三',得加上'\'',不是 张三

        sql = "select pwd from user_pwd where email =" + self.fill(self.email) + ';'
        # print(sql)

        try:
            n = self.cursor.execute(sql)
            data = self.cursor.fetchone()
        except Exception as e:
            print(e)
            return False

        if data == None:
            print('账号不存在')
            return False

        # self.cursor.execute(sql)

        sql2 = 'select * from user where email = ' + self.fill(self.email) + ';'
        # print(sql2)
        self.cursor.execute(sql2)
        data2 = self.cursor.fetchall()
        # print('data2:',data2)
        data2 = data2[0]
        # print(data2)
        self.name = data2[0]
        self.phone = data2[2]
        self.is_admin = data2[3]
        self.state = data2[4]
        self.company = data2[5]
        # 还要检查用户的状态 state
        if self.__pwd == data[0] and self.state == 1:
            # self.add_log_fail('登录成功') # 唯一一个，登录成功的log记录用登录失败的log函数来记录，因为此时self.live 没有被赋值
            return True  # 身份验证完毕，属于合法用户，成功登录
        else:
            print('密码错误或账号不可用')
            self.add_log_fail('登录失败')
            # 进行记录
            return False  # 登录失败

        # 调用示例:
        # 无需从外部调用，初始化user类之后，__init__()默认调用此方法

    def add_user_single(self, user_name, user_email, phone, is_admin, state, company_name):
        '''
        # 调用示例:
        # u 为已经实例化的user类
        # u.add_user_single('李四','132@qq.com','184******50',0,1,'company of XXX')
        # 姓名、邮箱不与已有用户的重复
        '''

        if self.live == False:
            return False  # 用户没有登录，拒绝操作
        # 私有方法，管理员才允许调用
        if self.is_admin:
            action = self.__add_user(user_name, user_email, phone, is_admin, state, company_name)
            if action:
                s = '添加用户 ' + user_name
                self.add_log_action(s)
                return True  # 用户添加成功
            else:
                return False  # 用户添加失败
        else:
            return False  # 此处的失败，是因为用户不是管理员

    # 添加用户属于私有方法，不允许被外部调用
    def __add_user(self, user_name, user_email, phone, is_admin, state, company_name):
        '''
        添加单个用户模块（前端同学注意，此函数为私有方法无需被调用，调用方法是公有的 add_user_single()
        添加用户信息，随机为用户分配密码,会同时更新2张表
        :param user_name: 用户名
        :param user_email:
        :param phone:
        :param is_admin: True 管理员; False 普通员工
        :param state: True 账号可用;False 账号不可用
        :param company_name: 此公司名必须是company表中，已经有的公司名，否则无法插入
        :return: True 添加成功; False 添加失败;
        '''
        param = (user_name, user_email, phone, is_admin, state, company_name)
        sql = 'insert into user values(%s,%s,%s,%s,%s,%s);'

        # 为用户生成随机密码
        pwd = ''.join(random.sample(string.digits + string.ascii_uppercase + string.ascii_lowercase, 8))

        param2 = (user_email, user_name, pwd)
        sql2 = 'insert into user_pwd values(%s,%s,%s,NULL,NULL);'

        try:
            n = self.cursor.execute(sql, param)
            # db.commit() # 必须加这句话，否则数据没有保存在数据库中（!!!）
        except Exception as e:
            self.db.rollback()  # 事务回滚，即出现错误后，不会继续执行，而是回到程序未执行的状态，原先执行的也不算了
            print(e)
            return False

        try:
            n = self.cursor.execute(sql2, param2)
            self.db.commit()  # 必须加这句话，否则数据没有保存在数据库中（!!!）
            return n
        except Exception as e:
            self.db.rollback()  # 事务回滚，即出现错误后，不会继续执行，而是回到程序未执行的状态，原先执行的也不算了
            print(e)
            return False

        # 调用示例:
        # 私有方法，无需从外部调用

    def send_code(self, email):
        '''

    # 调用示例:
    # 值得注意的是，修改密码就一定改，如果新提交的密码和原始密码一样则修改密码失败,return False。
    # u.send_code(u.email)
    # 此时请查看你的邮箱，填写验证码:code
    # code = input('查看邮箱的验证码:')
    # new_pwd = input('新的密码,不得和原来密码一样:')
    # u.recv_code(u.email,code,new_pwd) 
    忘记密码模块
    :email 请求修改密码的用户的邮箱
        注意：如果邮件发不出去，请联系我，因为邮箱的授权码，不在代码中
        忘记密码
        用户没有登录，用户提交他的邮箱，我们发验证码过去。
        '''
        code = send_verify_code('tiffany3344@163.com', email)
        # code = '74185269'
        # 将发送的验证码写入数据库
        # update user_pwd set code = '02345678',code_time = now() where email = '132@qq.com'; 
        sql = 'update user_pwd set code = ' + self.fill(code) + ',code_time = now() where email = ' + self.fill(email);
        print('验证码:', code)  # 输出验证码，仅仅为了方便调试
        # print(sql)
        try:
            n = self.cursor.execute(sql)
            self.db.commit()  # 必须加这句话，否则数据没有保存在数据库中（!!!）
            self.add_log_action('请求修改密码')
            return n
        except Exception as e:
            self.db.rollback()  # 事务回滚，即出现错误后，不会继续执行，而是回到程序未执行的状态，原先执行的也不算了
            print(e)
            return False

        # 调用示例:
        # 参考recv_code()的调用示例，一起调用

    def recv_code(self, email, code, new_pwd):
        '''
        忘记密码模块
        接受用户返回的验证码
        :email 请求修改密码的用户的邮箱
        :code 用户提交的验证码
        :new_pws 用户提交的新密码

        流程:
        1. 数据库查询发送给用户的验证码和发送验证码的时间
        2. 如果用户提交的验证码正确，
        3. 经过数据库查询，在5分钟之内
        4. 把用户提交的新密码，写进数据库
        '''
        sql = 'select code,code_time from user_pwd where email = ' + self.fill(email) + ';'
        # print(sql) 
        data = ''
        try:
            n = self.cursor.execute(sql)
            data = self.cursor.fetchone()
            # print(data)
        except Exception as e:
            self.db.rollback()  # 事务回滚，即出现错误后，不会继续执行，而是回到程序未执行的状态，原先执行的也不算了
            print(e)
            return False

        if data:

            if code == data[0]:
                print('提交的验证码正确')
            else:
                self.add_log_action('提交的修改密码的验证码错误')
                print('提交的验证码错误')
                # print(data[0])
                return False

            time = self.fill(str(data[1]))

            sql2 = 'select timestampdiff(minute,' + time + ',now());'
            # print(sql2)

            minute = -1  # minute:用户提交验证码的时间，和我们发送验证码的时间差
            try:
                self.cursor.execute(sql2)
                m = self.cursor.fetchone()
                # print(m)
                minute = int(m[0])
                # db.commit() # 必须加这句话，否则数据没有保存在数据库中（!!!）
            except Exception as e:
                self.db.rollback()  # 事务回滚
                print(e)
                return False

            if minute >= 0 and minute < 5:

                # 在验证码有效时间内，允许用户修改密码
                # sql3 = 'update user_pwd set pwd = 'newpwd' where email = 'tiffany33440@163.com';'
                sql3 = 'update user_pwd set pwd = ' + self.fill(new_pwd) + 'where email =' + self.fill(email) + ';'

                try:
                    n = self.cursor.execute(sql3)
                    if n:
                        print('密码修改成功')
                        self.add_log_action('修改密码成功')
                        self.db.commit()
                        return True
                    else:
                        self.add_log_action('修改密码失败')
                        print('n:', n, '密码修改失败')

                except Exception as e:
                    self.add_log_action('修改密码失败，程序代码异常')
                    self.db.rollback()  # 事务回滚
                    print(e)

                    return False
            else:
                self.add_log_action('提交修改密码的验证码超时')
                print('验证码时间超时')
                return False

    def delete_user_by_name(self, name):
        '''
        # 调用示例
        # u.delete_user_by_name('李四')
        '''
        if self.live == False:
            return False  # 用户没有登录，拒绝操作

        s = '删除用户' + name
        if self.is_admin:
            action = self.__delete_data(name)
            if action:

                self.add_log_action(s + '成功')
                return True  # 删除成功
            else:
                self.add_log_action(s + '失败')
                return False  # 删除失败
        else:

            s += '(越权操作已拒绝)'
            self.add_log_action(s)
            return False  # 用户不是管理员，没有删除权限

    def __delete_data(self, name):

        sql1 = 'delete ' + ' from ' + 'user_pwd' + ' where ' + ' name ' + ' = ' + self.fill(name) + ';'
        sql2 = 'delete ' + ' from ' + 'user' + ' where ' + ' name ' + ' = ' + self.fill(name) + ';'
        # print(sql1)
        # print(sql2)

        try:
            n = self.cursor.execute(sql1)
            # self.db.commit() # 必须加这句话，否则数据没有保存在数据库中（!!!）
        except Exception as e:
            self.db.rollback()  # 事务回滚，即出现错误后，不会继续执行，而是回到程序未执行的状态，原先执行的也不算了
            print(e)
            return False

        try:
            n = self.cursor.execute(sql2)
            self.db.commit()  # 必须加这句话，否则数据没有保存在数据库中（!!!）
            return n
        except Exception as e:
            self.db.rollback()  # 事务回滚，即出现错误后，不会继续执行，而是回到程序未执行的状态，原先执行的也不算了
            print(e)
            return False

        # 调用示例:
        # 删除用户属于私有方法，无需从外部调用

    def fuzz_search(self, name='', email='', phone=''):
        '''
        模糊查询模块
        调用示例:
        # u.fuzz_search(name='李',email='132',phone='')
        # u.fuzz_search(name='李',email='132')
        含义:查询名字带有'李',邮箱带有'132',手机号随意的所有用户。(参数为空字符串或者不填，代表无限制)
        '''
        clean_data_list()
        print('clean data')
        if self.live == False:
            return False  # 用户没有登录，拒绝操作
        sql = 'select * from user;'
        try:
            n = self.cursor.execute(sql)
            data = self.cursor.fetchall()

            s = '查询'
            if name:
                s += ' name带有' + name
            if email:
                s += ' email带有' + email
            if phone:
                s += ' phone带有' + phone
            s += '的用户信息'
            self.add_log_action(s)
            # print(data)
        except Exception as e:
            print(e)
        # data = list(data)
        for a in data:
            if name in a[0] and email in a[1] and phone in a[2]:
                insert_data_list(a[1],a[0],a[2])
                print(a)

    def alter_user_by_name(self, phone='', is_admin=-1, state=-1, name=''):
        '''
        # 调用示例:
        # u.alter_user_by_name(phone='13213',is_admin=1,state=0,name = '王4')  # 用户的姓名、邮箱不允许改
        # u.alter_user_by_name(phone='13213',name = '王4') # 参数可以少填，不填参数不改变，但是要修改对象的姓名必须填写
        '''
        is_admin = int(is_admin)
        state = int(state)
        if self.live == False:
            return False  # 用户没有登录，拒绝操作
        s = '修改' + name + '的'
        if phone:
            s += ' phone为' + phone
        if is_admin != -1:
            s += ' is_admin为' + str(is_admin)
        if state != -1:
            s += ' state为' + str(state)

        if self.is_admin:
            action = self.__alter_user_by_name(phone, is_admin, state, name)
            if action:

                self.add_log_action(s + ' 成功')

                return True  # 修改成功
            else:
                self.add_log_action('修改后信息与原信息一样(已拒绝)')
                return False  # 修改失败
        else:
            self.add_log_action(s + '(越权操作，已拒绝)')
            return False  # 用户不是管理员，没有删除权限

    def __alter_user_by_name(self, phone='', is_admin=-1, state=-1, name=''):
        '''
        # 修改用户的属性,修改user表,仅支持管理员来修改
        :return: True 修改成功; False 修改失败;
        '''
        is_admin = int(is_admin)
        state = int(state)
        if self.live == False:
            return False  # 用户没有登录，拒绝操作

        if name == '':
            # (我们也允许管理员修改自己的信息，管理员填自己的姓名也ok)
            print('你没有输入修改对象的姓名')
            return False

        if phone == '' and is_admin == -1 and state == -1:  # 没有任何修改，直接拒绝
            return False

        sql = 'update user set '
        if phone:
            sql_phone = ' phone = ' + self.fill(phone)
            sql += sql_phone
        if is_admin > -1 and self.is_admin:
            sql_is_admin = ', is_admin = ' + str(is_admin)
            sql += sql_is_admin
        if state > -1:
            sql_state = ', state = ' + str(state)
            sql += sql_state

        # 进行身份验证，普通用户只允许改自己的密码 
        sql += ' where name = ' + self.fill(name) + ';'

        # print(sql)
        try:
            n = self.cursor.execute(sql)
            self.db.commit()

            # 更新类中用户的属性，保持一致
            if phone:
                self.phone = phone
            if is_admin > -1 and self.is_admin:
                self.is_admin = is_admin
            if state > -1:
                self.state = state

            return n
        except Exception as e:
            self.db.rollback()  # 事务回滚
            print(e)
            return False

        # 调用示例:
        # 它是私有方法，参考alter_data_by_name()来调用它

    def alter_pwd_by_name(self, pwd, name=''):
        '''
        # 调用示例:
        # u.alter_pwd_by_name('new_password')  # 不填修改对象的名字，默认改自己的密码
        # u.alter_pwd_by_name('new_password','其他人')  # 修改其他人的密码，只有管理员才有此权限
        普通用户只能修改自己的的密码
        管理员可以修改所有人的密码
        '''
        if self.live == False:  # 用户没有登录，拒绝操作
            return False
        if pwd == '':
            # 修改密码为空字符串，直接拒绝,不允许的行为
            return False

        if name == '':
            name = self.name

        if self.is_admin == 0:
            if name != self.name:
                self.add_log_action('请求修改他人密码(越权操作，已拒绝)')
                return False  # 普通用户只能修改自己的密码，如果普通用户尝试修改他人的密码，直接拒绝
            sql = 'update user_pwd set pwd = ' + self.fill(pwd) + 'where name = ' + self.fill(self.name);

        elif self.is_admin == 1:

            # 管理员可以修改所有人的密码，（存在问题：不考虑管理员修改其他管理员密码的情况）
            sql = 'update user_pwd set pwd = ' + self.fill(pwd) + 'where name = ' + self.fill(name);

        try:
            n = self.cursor.execute(sql)
            if name == self.name:
                # 更改的是，当前类的属性
                self.__pwd = pwd  # 虽然用户的密码可能用不上，但是还是保持一致
            s = '修改' + name + '的密码'
            self.add_log_action(s)
            self.db.commit()
            return n
        except Exception as e:
            self.db.rollback()  # 事务回滚
            self.add_log_action('修改后的密码和原始密码一样(已拒绝)')
            print(e)
            return False


if __name__ == '__main__':
    u = user('tiffany33440@163.com', '123456')
    u.fuzz_search(name='李')


    #u.send_code(u.email)
    # 此时请查看你的邮箱，填写验证码:code
    #code = input('查看邮箱的验证码:')
    #new_pwd = input('新的密码,不得和原来密码一样:')
    #u.recv_code(u.email, code, new_pwd)

    # u.add_user_single('李时光','465431465@test.com','184******50',0,1,'company of XXX')
    # u.add_log_fail()
    # a = u.alter_pwd_by_name('new_pa1ssword','李7')
    # a = u.add_user_single('李时1234','13123000@qq.com','184******50',0,1,'company of XXX')
    # l = u.fuzz_search(name = '李',email = '131')
    # print(l)
    # a = u.delete_user_by_name('李时光')
    # a = u.alter_user_by_name(phone='10002546',name = '王4')
    # a = u.alter_pwd_by_name('4546','李7')