import os

def run_api(name):
    path = os.path.abspath(name)
    path1=' '
    for tmp in range(len(path)):
        if path[tmp] == '\\':
           path1+='/'
        else:
            path1+=path[tmp]
    a= 'python'+' '+path1
    os.system(a)


