import yagmail
yagmail.register('tiffany3344@163.com','WBVOMSMXEBWSTFBI')