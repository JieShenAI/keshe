from django.shortcuts import render,redirect
from .operation import *
from .db_login import *
from .user_class import user
import datetime


#用户登录界面
def insert(request):
    return render(request,'insert.html')


def jump(request):
    if request.method == "POST":
        username = request.POST.get("username", None)
        password = request.POST.get("password", None)
        if request.POST.get("login", None):
            if Authenticate(username, password):
                clean_temp_list()
                u = user(username, password)
                insert_temp_list(username,password)
                u.add_log_action(username+'登录成功')
                return redirect(show)
            else:
                u = user('root', '000000')
                u.add_log_fail(username+'登录失败')
                return redirect(insert)
        if request.POST.get("forget", None):
            return redirect(forget)


def upload(request):
    if request.method == "POST":
        if request.POST.get("show", None):
            return redirect(show)
        if request.POST.get("upload", None):
            path = request.POST.get("path", None)
            a, b = os.path.splitext(os.path.split(path)[1])
            name = a + b
            print(name)
            CreateObjects(name, path)
    return render(request, 'upload.html')

def user_log(request):
    sql = 'select * from user_log'
    cursor.execute(sql)
    info = cursor.fetchall()
    if request.method == "POST":
        if request.POST.get("manage", None):
            return redirect(manage)
        if request.POST.get("clean", None):
            clean_user_log()
    return render(request, 'user_log.html', {'info': info})

def search(request):
    sql = 'select * from data'
    cursor.execute(sql)
    data = cursor.fetchall()
    if request.method == "POST":
        if request.POST.get("manage", None):
            return redirect(manage)
    return render(request, 'search.html', {'data': data})

def manage(request):
    if request.method == "POST":
        sql = 'select * from temp'
        cursor.execute(sql)
        data = cursor.fetchone()
        u = user(data[0], data[1])
        name = request.POST.get("name", None)
        email = request.POST.get("email", None)
        phone = request.POST.get("phone", None)
        newpassword = request.POST.get("newpassword", None)
        newstate = request.POST.get("newstate", None)
        admin = request.POST.get("admin", None)
        if request.POST.get("function1", None):
            u.add_user_single(name,email,phone,admin,newstate,'company of XXX')
            print('添加用户')
        if request.POST.get("function2", None):
            u.delete_user_by_name(name)
            print('删除用户')
        if request.POST.get("function3", None):
            u.fuzz_search(name=name, email=email, phone=phone)
            print('模糊搜索')
            return redirect(search)
        if request.POST.get("function4", None):
            print('修改用户属性（管理员）')
            u.alter_user_by_name(phone=phone,state=newstate,name = name)
        if request.POST.get("function5", None):
            u.alter_pwd_by_name(newpassword,name)
            print('修改用户密码（管理员）')
        if request.POST.get("function6", None):
            return redirect(show)
        if request.POST.get("function7", None):
            return redirect(user_log)
    return render(request, 'manage.html')

def forget(request):
    if request.method == "POST":
        sql = 'select * from temp'
        cursor.execute(sql)
        data = cursor.fetchone()
        u = user(data[0], data[1])
        email = request.POST.get("s1", None)
        if request.POST.get("login", None):
            return redirect(insert)
        if request.POST.get("function1", None):
            u.send_code(email)
            print('验证码已发送')
        code = request.POST.get("s2", None)
        new_pw1 = request.POST.get("s3", None)
        new_pw2 = request.POST.get("s3", None)
        if request.POST.get("function2", None) and new_pw1==new_pw2:
            u.recv_code(email,code,new_pw1)
            print('修改密码操作已提交')
    return render(request, 'forget.html')



#用户登录界面
def insert(request):
    return render(request,'insert.html')

#显示对象列表
def show(request):
#加载最新的文件对象列表
    ListObjects()

    sql = 'select * from list'
    cursor.execute(sql)
    info = cursor.fetchall()

    if request.method == "POST":
        if request.POST.get("manage", None):
            return redirect(manage)
        if request.POST.get("upload", None):
            return redirect(upload)
        if request.POST.get("login", None):
            return redirect(insert)
        objectname = request.POST.get("path", None)
    #如果是对对象进行操作
        if request.POST.get("operate", None):
            #路径非空则执行对象操作--------
            if objectname !="":                                                          #（待补充：对对象名进行合法性检测）
                #清空临时存对象名字的数据库
                sql = "delete from objectname "
                cursor.execute(sql)
                db.commit()
                #将当前操作的对象名插入数据库
                sql = "insert into objectname values(" + "'" + objectname+ "'" + ");"
                cursor.execute(sql)
                db.commit()
                return redirect(operate_objects)
            else:
                return redirect(show)
    #如果是创建文件夹
        if request.POST.get("create", None):
            return redirect(operate)
        if request.POST.get("share_record",None):
            return redirect(show_share_record)
    return render(request, 'show.html', {'info': info})


#创建文件夹和返回对象列表
def operate(request):
    if request.method == "POST":
        if request.POST.get("CreateFile", None):
            print("yes")
            foldername = request.POST.get("foldername", None)
            print(foldername)
            reply = CreateFile(foldername)  #(reply = "yes"为创建成功，reply= "no"创建失败)
            return redirect(operate)
        if request.POST.get("ListObjects_demo", None):
            return redirect(show)
    return render(request,'operate.html')

#文件对象操作界面
def operate_objects(request):
    if request.method == 'POST':
    #如果是显示属性
        if  request.POST.get("attribute", None):
            print("attribute")
            sql = "select *from objectname"
            cursor.execute(sql)
            objectname = cursor.fetchone()[0]
            reply = getObjectMetadata(objectname)
            if reply == "yes":
                return redirect(show_attribute)
            else :
                return redirect(operate_objects)
    #如果是下载
        if request.POST.get("download", None):
            print("download")
            return redirect(down_load)
    #如果是复制
        if request.POST.get("copy", None):
            print("copy")
            return redirect(copy_move)
    #如果是删除
        if request.POST.get("delete", None):
            print("delete")
            return redirect(delete)
    #如果是分享
        if request.POST.get("share", None):
            print("share")
            return redirect(share)
     #返回对象列表
        if request.POST.get("ListObjects_demo", None):
            return redirect(show)
    return render(request,'operate_objects.html')

#------------------------------------------------------------分享界面------------------------------------------------------
def share(request):
    if request.method == "POST":
    #如果是确认创建分享
        if request.POST.get("OK", None):
            day = request.POST.get("day", None)
            if day not in ['1','2','3','4','5','6','7']:
                return redirect(share)
            else:
                day = int (day)
                sql = "select *from objectname"
                cursor.execute(sql)
                objectname = cursor.fetchone()[0]
            #创建分享链接
                url= Create_Share(objectname, day)
                print(url)

            #将分享记录存入数据库
            #主键
                time = datetime.datetime.now().strftime('%F %T') #获取当前的时间
                name_time = objectname +':' + time
                sql = "insert into share_record values(" + "'" + name_time + "'" + "," + "'" + url + "'" + ");"
                cursor.execute(sql)
                db.commit()
            #存储当前的分享链接
                #清空零时存储链接的表格
                sql = "delete from share_url "
                cursor.execute(sql)
                db.commit()
                #将当前的链接插入表格
                sql = "insert into share_url values( " + "'" + objectname + "'" + "," + "'" + url + "'" + ");"
                cursor.execute(sql)
                db.commit()
                return redirect(show_share_url)
    #返回操作列表
        if request.POST.get("back", None):
            return redirect(operate_objects)
    return render(request,'share.html')

def show_share_url(request):
    #获得当前的分享的链接
    sql = "select * from share_url"
    cursor.execute(sql)
    info = cursor.fetchall()
    if request.method == 'POST':
        if request.POST.get("operate",None):
            return redirect(operate_objects)
        if request.POST.get("logout",None):
            return redirect(insert)
    return render(request,'show_share_url.html',{'info': info})

def show_share_record(request):
    sql = "select * from share_record"
    cursor.execute(sql)
    info = cursor.fetchall()
    if request.method == 'POST':
        if request.POST.get("operate",None):
            return redirect(show)
    return render(request,'show_share_record.html',{'info': info})

#----------------------------------------------显示属性-------------------------------------
def show_attribute(request):
#得到文件地址
    sql = "select *from attribute"
    cursor.execute(sql)
    info = cursor.fetchall()
    print(info)
    if request.method == 'POST':
        if request.POST.get("operate", None):
            return redirect(operate_objects)
    return render(request,'show_attribute.html',{'info':info})

#---------------------------------------------下载界面--------------------------------------

def down_load(request):
#记载下载的文件名字
    sql = "select *from objectname"
    cursor.execute(sql)
    objectname = cursor.fetchone()[0]
    if request.method == "POST":
        downloadpath = request.POST.get("downloadpath",None)
        if request.POST.get("ok",None):
            Downloadobjects(objectname,downloadpath)
            return redirect(down_load)
        if request.POST.get("operate",None):
            return redirect(operate_objects)
    return render(request,"down_load.html")

#---------------------------------------------删除-------------------
def delete(request):
    sql = "select *from objectname"
    cursor.execute(sql)
    objectname = cursor.fetchone()[0]
    if request.method == "POST":
        if request.POST.get("ok",None):
            DeleteObject_single(objectname)
            return redirect(operate_objects)
        if request.POST.get("operate",None):
            return redirect(operate_objects)
    return render(request,"delete.html")

#---------------------------------复制_粘贴----------------------------------
def copy_move(request):
    sql = "select *from objectname"
    cursor.execute(sql)
    objectname = cursor.fetchone()[0]
#----------------------------更新到最新的文件对象列表------------------------------
    sql = 'delete from list'
    cursor.execute(sql)
    db.commit()
    ListObjects()

    sql = 'select * from list'
    cursor.execute(sql)
    info = cursor.fetchall()

    if request.method == 'POST':
        destobjectname = request.POST.get("path",None)
        if request.POST.get('ok',None):
            if destobjectname != "":
                CopyObject(objectname,destobjectname )
        if request.POST.get('operate',None):
            return redirect(operate_objects)
    return render(request,"copy_move.html",{'info':info})