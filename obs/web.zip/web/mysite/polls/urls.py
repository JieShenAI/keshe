from django.urls import re_path
from .views import *



urlpatterns = [
    re_path(r'^insert/', insert),
    re_path(r'^jump/', jump),
    re_path(r'^show/', show),
    re_path(r'^operate/', operate),
    re_path(r'^operate_objects/', operate_objects),
    re_path(r'^share/', share),
    re_path(r'^show_share_url/', show_share_url),
    re_path(r'^show_attribute/', show_attribute),
    re_path(r'^down_load/', down_load),
    re_path(r'^delete/', delete),
    re_path(r'^copy_move/', copy_move),
    re_path(r'^show_share_record/', show_share_record),
    re_path(r'^manage/', manage),
    re_path(r'^forget/', forget),
    re_path(r'^user_log/', user_log),
    re_path(r'^search/', search),
    re_path(r'^upload/', upload),
]